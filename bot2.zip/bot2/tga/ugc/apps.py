from django.apps import AppConfig


class UgcConfig(AppConfig):
    name = 'ugc'
    varbose_name = 'Основные Таблицы'
    default_auto_field = 'django.db.models.BigAutoField'
